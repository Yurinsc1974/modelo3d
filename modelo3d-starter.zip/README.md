# modelo3d-starter

Arquivos mínimos para rodar no GitHub Pages.

## Estrutura

- `index.html` — página principal (usa import map para `three` e `OrbitControls`).
- `data/Base.xlsx` — planilha de exemplo com cabeçalhos esperados.

## Como publicar

1. Crie um repositório e envie estes arquivos.
2. Em **Settings → Pages**, escolha **Deploy from branch** e branch `main`.
3. Acesse a URL do GitHub Pages.

> Observação: os ícones Material Symbols são carregados via Google Fonts e usam `font-variation-settings` para Outlined 300.

Gerado em 2025-08-25.
